
public class Calculator {

    public double add(double num1, double num2) {
        return num1 + num2;
    }

    public double subtract(double num1, double num2) {
        return num1 - num2;
    }

    public double multiply(double num1, double num2) {
        return num1 * num2;
    }

    public double divide(double num1, double num2) {
        if (num2 == 0) {
        	System.out.println("Result from server: Error");
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        else
        	
        	return num1 / num2;
    }
}

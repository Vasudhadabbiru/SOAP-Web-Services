
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class CalculatorClient {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter operation (add, subtract, multiply, divide):");
        String operation = scanner.nextLine();

        System.out.println("Enter the first number:");
        double num1 = scanner.nextDouble();

        System.out.println("Enter the second number:");
        double num2 = scanner.nextDouble();

        scanner.close();

        try {
            // URL of the server-side web service
            String baseUrl = "http://localhost:8081/BasicCalculator/services/Calculator/";
            String endpointUrl = baseUrl + operation + "?num1=" + num1 + "&num2=" + num2;

            // Create URL object for the operation endpoint
            URL url = new URL(endpointUrl);

            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set the request method to GET
            connection.setRequestMethod("GET");

            // Read the response from the server
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String response = reader.readLine();
            reader.close();

            // Print the result obtained from the server
            System.out.println("Result from server: " + response);

            // Disconnect the connection
            connection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
